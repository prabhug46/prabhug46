﻿Imports System.Data.OracleClient
Public Class Form1
    Dim con As OracleConnection
    Dim con1 As OracleConnection
    Dim cmd As OracleCommand
    Dim cmd1 As OracleCommand
    Dim obreader As OracleDataReader
    Dim id As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New OracleConnection("Data source=ashok;user id=scott;password=tiger")
        con.Open()
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        disp_data()
    End Sub

    Public Sub disp_data()
        Try
            Dim da As New OracleDataAdapter("SELECT * FROM bank ORDER BY accno", con)
            Dim dt As New DataTable()
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox("Error loading data: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick, DataGridView1.CellClick
        id = DataGridView1.SelectedCells.Item(0).Value.ToString()
        If (e.RowIndex) >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            ACCNO.Text = row.Cells(0).Value.ToString
            ACID.Text = row.Cells(1).Value.ToString
            cname.Text = row.Cells(2).Value.ToString
            PBAL.Text = row.Cells(3).Value.ToString
            ATYPE.Text = row.Cells(4).Value.ToString
            AMT.Text = row.Cells(5).Value.ToString
            DT.Text = row.Cells(6).Value.ToString
            CBAL.Text = row.Cells(7).Value.ToString
        End If
    End Sub


    Private Sub ADD1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADD1.Click
        ACCNO.Text = ""
        ACID.Text = " "
        cname.Text = ""
        ATYPE.Text = ""
        PBAL.Text = " "
        AMT.Text = ""
        DT.Text = ""
        CBAL.Text = " "
        ACCNO.Focus()
    End Sub

    Private Sub SAVE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SAVE1.Click
        Try
            Using con As New OracleConnection("Data source=ashok;user id=scott;password=tiger")
                con.Open()
                Using cmd As New OracleCommand("INSERT INTO bank VALUES(:accno, :acid, :cname, :pbal, :atype, :amt, :dt, :cbal)", con)
                    cmd.Parameters.Add(":accno", OracleType.VarChar).Value = ACCNO.Text
                    cmd.Parameters.Add(":acid", OracleType.VarChar).Value = ACID.Text
                    cmd.Parameters.Add(":cname", OracleType.VarChar).Value = cname.Text
                    cmd.Parameters.Add(":pbal", OracleType.Number).Value = Val(PBAL.Text)
                    cmd.Parameters.Add(":atype", OracleType.VarChar).Value = ATYPE.Text
                    cmd.Parameters.Add(":amt", OracleType.Number).Value = Val(AMT.Text)
                    cmd.Parameters.Add(":dt", OracleType.DateTime).Value = DateTime.Parse(DT.Text)
                    cmd.Parameters.Add(":cbal", OracleType.Number).Value = Val(CBAL.Text)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
            MsgBox("Updated Successfully")
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
        disp_data()
    End Sub

    Private Sub UPDATE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UPDATE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to update this record?", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "UPDATE bank SET cname = '" & cname.Text & "' WHERE accno = '" & ACCNO.Text & "'"
            cmd.ExecuteNonQuery()
        End If
        disp_data()
    End Sub

    Private Sub CLEAR1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CLEAR1.Click
        ACCNO.Text = ""
        ACID.Text = ""
        cname.Text = ""
        ATYPE.Text = ""
        PBAL.Text = ""
        AMT.Text = ""
        DT.Text = ""
        CBAL.Text = " "
    End Sub

    Private Sub ATYPE_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles ATYPE.GotFocus
        If RadioButton1.Checked = True Then
            ATYPE.Text = "Debit"
        Else
            ATYPE.Text = "Credit"
        End If
        AMT.Focus()
    End Sub

    Private Sub AMT_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles AMT.LostFocus
        If RadioButton1.Checked = True And ATYPE.Text = "Debit" Then
            If Val(AMT.Text) <= Val(PBAL.Text) Then
                DT.Focus()
            Else
                MsgBox("amount should be less than prev balance")
                AMT.Focus()
            End If
        End If
    End Sub

    Private Sub DT_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles DT.GotFocus
        DT.Text = Date.Today
    End Sub

    Private Sub CBAL_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles CBAL.GotFocus
        Dim prevBalance As Double = If(IsNumeric(PBAL.Text), Val(PBAL.Text), 0)
        Dim amount As Double = If(IsNumeric(AMT.Text), Val(AMT.Text), 0)

        If RadioButton1.Checked And ATYPE.Text = "Debit" Then
            CBAL.Text = prevBalance - amount
        ElseIf RadioButton2.Checked And ATYPE.Text = "Credit" Then
            CBAL.Text = prevBalance + amount
        End If
    End Sub

    Private Sub EXIT1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXIT1.Click
        End
    End Sub
End Class

