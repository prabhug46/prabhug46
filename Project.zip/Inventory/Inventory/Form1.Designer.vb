﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ADD = New System.Windows.Forms.Button
        Me.SAVE = New System.Windows.Forms.Button
        Me.DELETE = New System.Windows.Forms.Button
        Me.UPDATE1 = New System.Windows.Forms.Button
        Me.EXIT1 = New System.Windows.Forms.Button
        Me.CLEAR = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.pid = New System.Windows.Forms.TextBox
        Me.pdesc = New System.Windows.Forms.TextBox
        Me.uprice = New System.Windows.Forms.TextBox
        Me.qoh = New System.Windows.Forms.TextBox
        Me.tstock = New System.Windows.Forms.TextBox
        Me.tcost = New System.Windows.Forms.TextBox
        Me.rol = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ADD
        '
        Me.ADD.Location = New System.Drawing.Point(103, 338)
        Me.ADD.Name = "ADD"
        Me.ADD.Size = New System.Drawing.Size(75, 23)
        Me.ADD.TabIndex = 0
        Me.ADD.Text = "ADD"
        Me.ADD.UseVisualStyleBackColor = True
        '
        'SAVE
        '
        Me.SAVE.Location = New System.Drawing.Point(185, 337)
        Me.SAVE.Name = "SAVE"
        Me.SAVE.Size = New System.Drawing.Size(75, 23)
        Me.SAVE.TabIndex = 1
        Me.SAVE.Text = "SAVE"
        Me.SAVE.UseVisualStyleBackColor = True
        '
        'DELETE
        '
        Me.DELETE.Location = New System.Drawing.Point(348, 337)
        Me.DELETE.Name = "DELETE"
        Me.DELETE.Size = New System.Drawing.Size(75, 23)
        Me.DELETE.TabIndex = 3
        Me.DELETE.Text = "DELETE"
        Me.DELETE.UseVisualStyleBackColor = True
        '
        'UPDATE1
        '
        Me.UPDATE1.Location = New System.Drawing.Point(266, 338)
        Me.UPDATE1.Name = "UPDATE1"
        Me.UPDATE1.Size = New System.Drawing.Size(75, 23)
        Me.UPDATE1.TabIndex = 2
        Me.UPDATE1.Text = "UPDATE"
        Me.UPDATE1.UseVisualStyleBackColor = True
        '
        'EXIT1
        '
        Me.EXIT1.Location = New System.Drawing.Point(511, 337)
        Me.EXIT1.Name = "EXIT1"
        Me.EXIT1.Size = New System.Drawing.Size(75, 23)
        Me.EXIT1.TabIndex = 5
        Me.EXIT1.Text = "EXIT"
        Me.EXIT1.UseVisualStyleBackColor = True
        '
        'CLEAR
        '
        Me.CLEAR.Location = New System.Drawing.Point(429, 338)
        Me.CLEAR.Name = "CLEAR"
        Me.CLEAR.Size = New System.Drawing.Size(75, 23)
        Me.CLEAR.TabIndex = 4
        Me.CLEAR.Text = "CLEAR"
        Me.CLEAR.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(38, 93)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(110, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Product transaction id"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(38, 124)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Product Description"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 159)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(90, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Quantity on Hand"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(38, 185)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Unit Price"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(38, 211)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 13)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Reorder level"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(38, 242)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 13)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Total cost"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(38, 273)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Total Stock"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5})
        Me.DataGridView1.Location = New System.Drawing.Point(302, 93)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(523, 150)
        Me.DataGridView1.TabIndex = 13
        '
        'Column1
        '
        Me.Column1.HeaderText = "PROID"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "PDES"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "QOH"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "UPRICE"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "ROL"
        Me.Column5.Name = "Column5"
        '
        'pid
        '
        Me.pid.Location = New System.Drawing.Point(160, 91)
        Me.pid.Name = "pid"
        Me.pid.Size = New System.Drawing.Size(100, 20)
        Me.pid.TabIndex = 14
        '
        'pdesc
        '
        Me.pdesc.Location = New System.Drawing.Point(160, 117)
        Me.pdesc.Name = "pdesc"
        Me.pdesc.Size = New System.Drawing.Size(100, 20)
        Me.pdesc.TabIndex = 15
        '
        'uprice
        '
        Me.uprice.Location = New System.Drawing.Point(160, 176)
        Me.uprice.Name = "uprice"
        Me.uprice.Size = New System.Drawing.Size(100, 20)
        Me.uprice.TabIndex = 17
        '
        'qoh
        '
        Me.qoh.Location = New System.Drawing.Point(160, 150)
        Me.qoh.Name = "qoh"
        Me.qoh.Size = New System.Drawing.Size(100, 20)
        Me.qoh.TabIndex = 16
        '
        'tstock
        '
        Me.tstock.Location = New System.Drawing.Point(160, 264)
        Me.tstock.Name = "tstock"
        Me.tstock.Size = New System.Drawing.Size(100, 20)
        Me.tstock.TabIndex = 18
        '
        'tcost
        '
        Me.tcost.Location = New System.Drawing.Point(160, 228)
        Me.tcost.Name = "tcost"
        Me.tcost.Size = New System.Drawing.Size(100, 20)
        Me.tcost.TabIndex = 21
        '
        'rol
        '
        Me.rol.Location = New System.Drawing.Point(160, 202)
        Me.rol.Name = "rol"
        Me.rol.Size = New System.Drawing.Size(100, 20)
        Me.rol.TabIndex = 20
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(261, 19)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(262, 29)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Inventory Transaction"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(852, 382)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tcost)
        Me.Controls.Add(Me.rol)
        Me.Controls.Add(Me.tstock)
        Me.Controls.Add(Me.uprice)
        Me.Controls.Add(Me.qoh)
        Me.Controls.Add(Me.pdesc)
        Me.Controls.Add(Me.pid)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.EXIT1)
        Me.Controls.Add(Me.CLEAR)
        Me.Controls.Add(Me.DELETE)
        Me.Controls.Add(Me.UPDATE1)
        Me.Controls.Add(Me.SAVE)
        Me.Controls.Add(Me.ADD)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ADD As System.Windows.Forms.Button
    Friend WithEvents SAVE As System.Windows.Forms.Button
    Friend WithEvents DELETE As System.Windows.Forms.Button
    Friend WithEvents UPDATE1 As System.Windows.Forms.Button
    Friend WithEvents EXIT1 As System.Windows.Forms.Button
    Friend WithEvents CLEAR As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pid As System.Windows.Forms.TextBox
    Friend WithEvents pdesc As System.Windows.Forms.TextBox
    Friend WithEvents uprice As System.Windows.Forms.TextBox
    Friend WithEvents qoh As System.Windows.Forms.TextBox
    Friend WithEvents tstock As System.Windows.Forms.TextBox
    Friend WithEvents tcost As System.Windows.Forms.TextBox
    Friend WithEvents rol As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label

End Class
