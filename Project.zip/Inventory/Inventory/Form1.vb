﻿Imports System.Data.OracleClient
Public Class Form1
    Dim con As OracleConnection
    Dim cmd As OracleCommand
    Dim obreader As OracleDataReader
    Dim id As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New OracleConnection("Data source=ashok;user id=scott;password=tiger")
        con.Open()
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        disp_data()
    End Sub

    Public Sub disp_data()
        Dim dt As New DataTable()
        Using cmd As New OracleCommand("SELECT * FROM inv", con)
            Using da As New OracleDataAdapter(cmd)
                da.Fill(dt)
            End Using
        End Using
        DataGridView1.DataSource = dt
    End Sub

    Private Sub SAVE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SAVE.Click
        If ((pid.Text <> "") And (pdesc.Text <> "") And (qoh.Text <> "") And (rol.Text <> "") And (uprice.Text <> "") And (tcost.Text <> "") And (tstock.Text <> "")) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "INSERT INTO inv VALUES (:pid, :pdesc, :qoh, :rol, :uprice, :tcost, :tstock)"
            cmd.Parameters.Add(New OracleParameter(":pid", pid.Text))
            cmd.Parameters.Add(New OracleParameter(":pdesc", pdesc.Text))
            cmd.Parameters.Add(New OracleParameter(":qoh", Convert.ToInt32(qoh.Text)))
            cmd.Parameters.Add(New OracleParameter(":rol", Convert.ToInt32(rol.Text)))
            cmd.Parameters.Add(New OracleParameter(":uprice", Convert.ToDecimal(uprice.Text)))
            cmd.Parameters.Add(New OracleParameter(":tcost", Convert.ToDecimal(tcost.Text)))
            cmd.Parameters.Add(New OracleParameter(":tstock", Convert.ToInt32(tstock.Text)))
            cmd.ExecuteNonQuery()
            CLEAR_Click(sender, e)
            disp_data()
            MessageBox.Show("Updated successfully")
        Else
            MsgBox("ADD Inventory INFO")
        End If
    End Sub

    Private Sub UPDATE1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles UPDATE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to update this record?", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "UPDATE inv SET pdesc=:pdesc, qoh=:qoh, uprice=:uprice, rol=:rol, tcost=:tcost, tstock=:tstock WHERE proid=:pid"
            cmd.Parameters.Add(New OracleParameter(":pdesc", pdesc.Text))
            cmd.Parameters.Add(New OracleParameter(":qoh", Convert.ToInt32(qoh.Text)))
            cmd.Parameters.Add(New OracleParameter(":uprice", Convert.ToDecimal(uprice.Text)))
            cmd.Parameters.Add(New OracleParameter(":rol", Convert.ToInt32(rol.Text)))
            cmd.Parameters.Add(New OracleParameter(":tcost", Convert.ToDecimal(tcost.Text)))
            cmd.Parameters.Add(New OracleParameter(":tstock", Convert.ToInt32(tstock.Text)))
            cmd.Parameters.Add(New OracleParameter(":pid", pid.Text))
            cmd.ExecuteNonQuery()
            disp_data()
        End If
    End Sub

    Private Sub DELETE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DELETE.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to delete this record?", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "DELETE FROM inv WHERE proid=:pid"
            cmd.Parameters.Add(New OracleParameter(":pid", pid.Text))
            cmd.ExecuteNonQuery()
            disp_data()
        End If
    End Sub

    Private Sub EXIT1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles EXIT1.Click
        Me.Close()
    End Sub

    Private Sub CLEAR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CLEAR.Click
        pid.Text = ""
        pdesc.Text = ""
        qoh.Text = ""
        rol.Text = ""
        uprice.Text = ""
        tcost.Text = ""
        tstock.Text = ""
    End Sub

    Private Sub ADD_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ADD.Click
        If ((pid.Text <> "") And (pdesc.Text <> "") And (qoh.Text <> "") And (rol.Text <> "") And (uprice.Text <> "") And (tcost.Text <> "") And (tstock.Text <> "")) Then
            Try
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "INSERT INTO inv (proid, pdesc, qoh, rol, uprice, tcost, tstock) VALUES (:proid, :pdesc, :qoh, :rol, :uprice, :tcost, :tstock)"
                cmd.Parameters.Add(New OracleParameter("proid", pid.Text))
                cmd.Parameters.Add(New OracleParameter("pdesc", pdesc.Text))
                cmd.Parameters.Add(New OracleParameter("qoh", Convert.ToInt32(qoh.Text)))
                cmd.Parameters.Add(New OracleParameter("rol", Convert.ToInt32(rol.Text)))
                cmd.Parameters.Add(New OracleParameter("uprice", Convert.ToDecimal(uprice.Text)))
                cmd.Parameters.Add(New OracleParameter("tcost", Convert.ToDecimal(tcost.Text)))
                cmd.Parameters.Add(New OracleParameter("tstock", Convert.ToInt32(tstock.Text)))

                cmd.ExecuteNonQuery()
                MessageBox.Show("Record Added Successfully")


                pid.Text = ""
                pdesc.Text = ""
                qoh.Text = ""
                rol.Text = ""
                uprice.Text = ""
                tcost.Text = ""
                tstock.Text = ""

                disp_data()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        Else
            MessageBox.Show("Please fill in all fields.")
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            pid.Text = row.Cells(0).Value.ToString()
            pdesc.Text = row.Cells(1).Value.ToString()
            qoh.Text = row.Cells(2).Value.ToString()
            rol.Text = row.Cells(3).Value.ToString()
            uprice.Text = row.Cells(4).Value.ToString()
            tcost.Text = row.Cells(5).Value.ToString()
            tstock.Text = row.Cells(6).Value.ToString()
        End If
    End Sub

    Private Sub tstock_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tstock.LostFocus
        tstock.Text = (Val(rol.Text) + Val(qoh.Text)).ToString()
    End Sub
End Class
