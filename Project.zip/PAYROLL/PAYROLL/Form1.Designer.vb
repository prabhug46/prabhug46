﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EMPNO = New System.Windows.Forms.TextBox
        Me.BASIC = New System.Windows.Forms.TextBox
        Me.DOJ = New System.Windows.Forms.TextBox
        Me.DESIG = New System.Windows.Forms.TextBox
        Me.ENAME = New System.Windows.Forms.TextBox
        Me.PF = New System.Windows.Forms.TextBox
        Me.TAX = New System.Windows.Forms.TextBox
        Me.GROSS = New System.Windows.Forms.TextBox
        Me.NET = New System.Windows.Forms.TextBox
        Me.CCA = New System.Windows.Forms.TextBox
        Me.HRA = New System.Windows.Forms.TextBox
        Me.DA = New System.Windows.Forms.TextBox
        Me.ADD1 = New System.Windows.Forms.Button
        Me.UPDATE1 = New System.Windows.Forms.Button
        Me.SAVE1 = New System.Windows.Forms.Button
        Me.CLEAR1 = New System.Windows.Forms.Button
        Me.EXIT1 = New System.Windows.Forms.Button
        Me.DELETE1 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3})
        Me.DataGridView1.Location = New System.Drawing.Point(443, 116)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(322, 150)
        Me.DataGridView1.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "EMPNO"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "NAME"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "DESIG"
        Me.Column3.Name = "Column3"
        '
        'EMPNO
        '
        Me.EMPNO.Location = New System.Drawing.Point(112, 116)
        Me.EMPNO.Name = "EMPNO"
        Me.EMPNO.Size = New System.Drawing.Size(100, 20)
        Me.EMPNO.TabIndex = 1
        '
        'BASIC
        '
        Me.BASIC.Location = New System.Drawing.Point(112, 220)
        Me.BASIC.Name = "BASIC"
        Me.BASIC.Size = New System.Drawing.Size(100, 20)
        Me.BASIC.TabIndex = 2
        '
        'DOJ
        '
        Me.DOJ.Location = New System.Drawing.Point(112, 194)
        Me.DOJ.Name = "DOJ"
        Me.DOJ.Size = New System.Drawing.Size(100, 20)
        Me.DOJ.TabIndex = 3
        '
        'DESIG
        '
        Me.DESIG.Location = New System.Drawing.Point(112, 168)
        Me.DESIG.Name = "DESIG"
        Me.DESIG.Size = New System.Drawing.Size(100, 20)
        Me.DESIG.TabIndex = 4
        '
        'ENAME
        '
        Me.ENAME.Location = New System.Drawing.Point(112, 142)
        Me.ENAME.Name = "ENAME"
        Me.ENAME.Size = New System.Drawing.Size(100, 20)
        Me.ENAME.TabIndex = 5
        '
        'PF
        '
        Me.PF.Location = New System.Drawing.Point(318, 142)
        Me.PF.Name = "PF"
        Me.PF.Size = New System.Drawing.Size(100, 20)
        Me.PF.TabIndex = 10
        '
        'TAX
        '
        Me.TAX.Location = New System.Drawing.Point(318, 168)
        Me.TAX.Name = "TAX"
        Me.TAX.Size = New System.Drawing.Size(100, 20)
        Me.TAX.TabIndex = 9
        '
        'GROSS
        '
        Me.GROSS.Location = New System.Drawing.Point(318, 194)
        Me.GROSS.Name = "GROSS"
        Me.GROSS.Size = New System.Drawing.Size(100, 20)
        Me.GROSS.TabIndex = 8
        '
        'NET
        '
        Me.NET.Location = New System.Drawing.Point(318, 220)
        Me.NET.Name = "NET"
        Me.NET.Size = New System.Drawing.Size(100, 20)
        Me.NET.TabIndex = 7
        '
        'CCA
        '
        Me.CCA.Location = New System.Drawing.Point(318, 116)
        Me.CCA.Name = "CCA"
        Me.CCA.Size = New System.Drawing.Size(100, 20)
        Me.CCA.TabIndex = 6
        '
        'HRA
        '
        Me.HRA.Location = New System.Drawing.Point(112, 246)
        Me.HRA.Name = "HRA"
        Me.HRA.Size = New System.Drawing.Size(100, 20)
        Me.HRA.TabIndex = 13
        '
        'DA
        '
        Me.DA.Location = New System.Drawing.Point(112, 272)
        Me.DA.Name = "DA"
        Me.DA.Size = New System.Drawing.Size(100, 20)
        Me.DA.TabIndex = 12
        '
        'ADD1
        '
        Me.ADD1.Location = New System.Drawing.Point(100, 360)
        Me.ADD1.Name = "ADD1"
        Me.ADD1.Size = New System.Drawing.Size(75, 23)
        Me.ADD1.TabIndex = 14
        Me.ADD1.Text = "ADD"
        Me.ADD1.UseVisualStyleBackColor = True
        '
        'UPDATE1
        '
        Me.UPDATE1.Location = New System.Drawing.Point(262, 360)
        Me.UPDATE1.Name = "UPDATE1"
        Me.UPDATE1.Size = New System.Drawing.Size(75, 23)
        Me.UPDATE1.TabIndex = 15
        Me.UPDATE1.Text = "UPDATE"
        Me.UPDATE1.UseVisualStyleBackColor = True
        '
        'SAVE1
        '
        Me.SAVE1.Location = New System.Drawing.Point(181, 360)
        Me.SAVE1.Name = "SAVE1"
        Me.SAVE1.Size = New System.Drawing.Size(75, 23)
        Me.SAVE1.TabIndex = 16
        Me.SAVE1.Text = "SAVE"
        Me.SAVE1.UseVisualStyleBackColor = True
        '
        'CLEAR1
        '
        Me.CLEAR1.Location = New System.Drawing.Point(424, 360)
        Me.CLEAR1.Name = "CLEAR1"
        Me.CLEAR1.Size = New System.Drawing.Size(75, 23)
        Me.CLEAR1.TabIndex = 19
        Me.CLEAR1.Text = "CLEAR"
        Me.CLEAR1.UseVisualStyleBackColor = True
        '
        'EXIT1
        '
        Me.EXIT1.Location = New System.Drawing.Point(505, 360)
        Me.EXIT1.Name = "EXIT1"
        Me.EXIT1.Size = New System.Drawing.Size(75, 23)
        Me.EXIT1.TabIndex = 18
        Me.EXIT1.Text = "EXIT"
        Me.EXIT1.UseVisualStyleBackColor = True
        '
        'DELETE1
        '
        Me.DELETE1.Location = New System.Drawing.Point(343, 360)
        Me.DELETE1.Name = "DELETE1"
        Me.DELETE1.Size = New System.Drawing.Size(75, 23)
        Me.DELETE1.TabIndex = 17
        Me.DELETE1.Text = "DELETE"
        Me.DELETE1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(29, 122)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "EMP NO"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(29, 149)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "NAME"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 175)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "DESGINATION"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 201)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "DT OF JOINING"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 227)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 13)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "BASIC"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(29, 253)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "HRA"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(29, 279)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(22, 13)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "DA"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(242, 227)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 13)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "NET"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(242, 201)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 13)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "GROSS"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(242, 175)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(28, 13)
        Me.Label10.TabIndex = 29
        Me.Label10.Text = "TAX"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(242, 149)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(20, 13)
        Me.Label11.TabIndex = 28
        Me.Label11.Text = "PF"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(242, 122)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(28, 13)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "CCA"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft PhagsPa", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(256, 9)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(218, 32)
        Me.Label13.TabIndex = 32
        Me.Label13.Text = "PAYROLL SYSTEM"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(777, 417)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CLEAR1)
        Me.Controls.Add(Me.EXIT1)
        Me.Controls.Add(Me.DELETE1)
        Me.Controls.Add(Me.SAVE1)
        Me.Controls.Add(Me.UPDATE1)
        Me.Controls.Add(Me.ADD1)
        Me.Controls.Add(Me.HRA)
        Me.Controls.Add(Me.DA)
        Me.Controls.Add(Me.PF)
        Me.Controls.Add(Me.TAX)
        Me.Controls.Add(Me.GROSS)
        Me.Controls.Add(Me.NET)
        Me.Controls.Add(Me.CCA)
        Me.Controls.Add(Me.ENAME)
        Me.Controls.Add(Me.DESIG)
        Me.Controls.Add(Me.DOJ)
        Me.Controls.Add(Me.BASIC)
        Me.Controls.Add(Me.EMPNO)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EMPNO As System.Windows.Forms.TextBox
    Friend WithEvents BASIC As System.Windows.Forms.TextBox
    Friend WithEvents DOJ As System.Windows.Forms.TextBox
    Friend WithEvents DESIG As System.Windows.Forms.TextBox
    Friend WithEvents ENAME As System.Windows.Forms.TextBox
    Friend WithEvents PF As System.Windows.Forms.TextBox
    Friend WithEvents TAX As System.Windows.Forms.TextBox
    Friend WithEvents GROSS As System.Windows.Forms.TextBox
    Friend WithEvents NET As System.Windows.Forms.TextBox
    Friend WithEvents CCA As System.Windows.Forms.TextBox
    Friend WithEvents HRA As System.Windows.Forms.TextBox
    Friend WithEvents DA As System.Windows.Forms.TextBox
    Friend WithEvents ADD1 As System.Windows.Forms.Button
    Friend WithEvents UPDATE1 As System.Windows.Forms.Button
    Friend WithEvents SAVE1 As System.Windows.Forms.Button
    Friend WithEvents CLEAR1 As System.Windows.Forms.Button
    Friend WithEvents EXIT1 As System.Windows.Forms.Button
    Friend WithEvents DELETE1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label

End Class
