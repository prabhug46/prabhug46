﻿Imports System.Data.OracleClient

Public Class Form1
    Dim con As OracleConnection
    Dim cmd As OracleCommand
    Dim obreader As OracleDataReader
    Dim id As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New OracleConnection("Data source=ashok;user id=scott;password=tiger")
        con.Open()
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        disp_data()
    End Sub

    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM payroll ORDER BY EMPNO"
        Dim da As New OracleDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick, DataGridView1.CellClick
        id = DataGridView1.SelectedCells.Item(0).Value.ToString()
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            EMPNO.Text = row.Cells(0).Value.ToString()
            ENAME.Text = row.Cells(1).Value.ToString()
            DESIG.Text = row.Cells(2).Value.ToString()
            DOJ.Text = row.Cells(3).Value.ToString()
            BASIC.Text = row.Cells(4).Value.ToString()
            DA.Text = row.Cells(5).Value.ToString()
            HRA.Text = row.Cells(6).Value.ToString()
            CCA.Text = row.Cells(7).Value.ToString()
            PF.Text = row.Cells(8).Value.ToString()
            TAX.Text = row.Cells(9).Value.ToString()
            GROSS.Text = row.Cells(10).Value.ToString()
            NET.Text = row.Cells(11).Value.ToString()
        End If
    End Sub

    Private Sub ADD1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADD1.Click
        EMPNO.Text = ""
        ENAME.Text = ""
        DESIG.Text = ""
        DOJ.Text = ""
        BASIC.Text = ""
        DA.Text = ""
        HRA.Text = ""
        CCA.Text = ""
        PF.Text = ""
        TAX.Text = ""
        GROSS.Text = ""
        NET.Text = ""
        EMPNO.Focus()
    End Sub

    Private Sub SAVE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SAVE1.Click
        Try
            If EMPNO.Text <> "" And ENAME.Text <> "" And DESIG.Text <> "" And DOJ.Text <> "" And BASIC.Text <> "" And DA.Text <> "" And HRA.Text <> "" And CCA.Text <> "" And PF.Text <> "" And TAX.Text <> "" And GROSS.Text <> "" And NET.Text <> "" Then
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "INSERT INTO payroll VALUES (:EMPNO, :ENAME, :DESIG, TO_DATE(:DOJ, 'YYYY-MM-DD'), :BASIC, :DA, :HRA, :CCA, :PF, :TAX, :GROSS, :NET)"

                cmd.Parameters.Add(New OracleParameter(":EMPNO", EMPNO.Text))
                cmd.Parameters.Add(New OracleParameter(":ENAME", ENAME.Text))
                cmd.Parameters.Add(New OracleParameter(":DESIG", DESIG.Text))
                cmd.Parameters.Add(New OracleParameter(":DOJ", DOJ.Text))
                cmd.Parameters.Add(New OracleParameter(":BASIC", BASIC.Text))
                cmd.Parameters.Add(New OracleParameter(":DA", DA.Text))
                cmd.Parameters.Add(New OracleParameter(":HRA", HRA.Text))
                cmd.Parameters.Add(New OracleParameter(":CCA", CCA.Text))
                cmd.Parameters.Add(New OracleParameter(":PF", PF.Text))
                cmd.Parameters.Add(New OracleParameter(":TAX", TAX.Text))
                cmd.Parameters.Add(New OracleParameter(":GROSS", GROSS.Text))
                cmd.Parameters.Add(New OracleParameter(":NET", NET.Text))

                cmd.ExecuteNonQuery()

                MessageBox.Show("Record inserted successfully!")
                disp_data()
            Else
                MsgBox("Enter all employee details.")
            End If
        Catch ex As Exception
            MsgBox("Error inserting record: " & ex.Message)
        End Try
    End Sub


    Private Sub DELETE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DELETE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to delete this record?", vbYesNo)
        If opt = vbYes Then
            Try
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "DELETE FROM payroll WHERE EMPNO = :EMPNO"
                cmd.Parameters.Add(New OracleParameter(":EMPNO", EMPNO.Text))

                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                If rowsAffected > 0 Then
                    MsgBox("Record deleted successfully!")
                Else
                    MsgBox("No matching record found.")
                End If

                disp_data()
            Catch ex As Exception
                MsgBox("Error deleting record: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub BASIC_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles BASIC.LostFocus
        DA.Text = Val(BASIC.Text) * 0.25
        HRA.Text = Val(BASIC.Text) * 0.3
        CCA.Text = Val(BASIC.Text) * 0.15
        PF.Text = Val(BASIC.Text) * 0.125
        TAX.Text = Val(BASIC.Text) * 0.1
        GROSS.Text = Val(BASIC.Text) + Val(DA.Text) + Val(HRA.Text) + Val(CCA.Text)
        NET.Text = Val(GROSS.Text) - Val(PF.Text) - Val(TAX.Text)
    End Sub

    Private Sub EXIT1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXIT1.Click
        con.Close()
        End
    End Sub

    Private Sub UPDATE1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles UPDATE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to update this record?", vbYesNo)
        If opt = vbYes Then
            Try
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "UPDATE payroll SET ENAME = :ENAME, DESIG = :DESIG, DOJ = TO_DATE(:DOJ, 'DD-MON-YYYY'), BASIC = :BASIC, DA = :DA, HRA = :HRA, CCA = :CCA, PF = :PF, TAX = :TAX, GROSS = :GROSS, NET = :NET WHERE EMPNO = :EMPNO"

                cmd.Parameters.Clear()
                cmd.Parameters.Add(New OracleParameter(":EMPNO", EMPNO.Text))
                cmd.Parameters.Add(New OracleParameter(":ENAME", ENAME.Text))
                cmd.Parameters.Add(New OracleParameter(":DESIG", DESIG.Text))
                cmd.Parameters.Add(New OracleParameter(":DOJ", DOJ.Text))
                cmd.Parameters.Add(New OracleParameter(":BASIC", Convert.ToDouble(BASIC.Text)))
                cmd.Parameters.Add(New OracleParameter(":DA", Convert.ToDouble(DA.Text)))
                cmd.Parameters.Add(New OracleParameter(":HRA", Convert.ToDouble(HRA.Text)))
                cmd.Parameters.Add(New OracleParameter(":CCA", Convert.ToDouble(CCA.Text)))
                cmd.Parameters.Add(New OracleParameter(":PF", Convert.ToDouble(PF.Text)))
                cmd.Parameters.Add(New OracleParameter(":TAX", Convert.ToDouble(TAX.Text)))
                cmd.Parameters.Add(New OracleParameter(":GROSS", Convert.ToDouble(GROSS.Text)))
                cmd.Parameters.Add(New OracleParameter(":NET", Convert.ToDouble(NET.Text)))

                cmd.ExecuteNonQuery()
                MessageBox.Show("Record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                disp_data() ' Refresh the DataGridView

            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub CLEAR1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CLEAR1.Click
        EMPNO.Text = ""
        ENAME.Text = ""
        DESIG.Text = ""
        DOJ.Text = " "
        BASIC.Text = " "
        DA.Text = ""
        HRA.Text = ""
        CCA.Text = ""
        PF.Text = ""
        TAX.Text = " "
        GROSS.Text = ""
        NET.Text = ""
    End Sub
End Class
