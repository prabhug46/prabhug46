﻿Imports System.Data.OracleClient
Public Class Form1
    Dim con As OracleConnection
    Dim cmd As OracleCommand
    Dim obreader As OracleDataReader
    Dim id As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New OracleConnection("Data source= rdbms;user id = stud;password = stud")
        con.Open()
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        disp_data()
    End Sub

    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from payroll order by EMPNO"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New OracleDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick, DataGridView1.CellClick
        id = DataGridView1.SelectedCells.Item(0).Value.ToString()
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            EMPNO.Text = row.Cells(0).Value.ToString
            ENAME.Text = row.Cells(1).Value.ToString
            DESIG.Text = row.Cells(2).Value.ToString
            DOJ.Text = row.Cells(3).Value.ToString
            BASIC.Text = row.Cells(4).Value.ToString
            DA.Text = row.Cells(5).Value.ToString
            HRA.Text = row.Cells(6).Value.ToString
            CCA.Text = row.Cells(7).Value.ToString
            PF.Text = row.Cells(8).Value.ToString
            TAX.Text = row.Cells(9).Value.ToString
            GROSS.Text = row.Cells(9).Value.ToString
            NET.Text = row.Cells(9).Value.ToString
        End If
    End Sub

    Private Sub ADD1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADD1.Click
        EMPNO.Text = ""
        ENAME.Text = ""
        DESIG.Text = ""
        DOJ.Text = " "
        BASIC.Text = " "
        DA.Text = ""
        HRA.Text = ""
        CCA.Text = ""
        PF.Text = ""
        TAX.Text = " "
        GROSS.Text = ""
        NET.Text = ""
        EMPNO.Focus()
    End Sub

    Private Sub SAVE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SAVE1.Click
        Try
            If ((EMPNO.Text <> "") And (ENAME.Text <> "") And (DESIG.Text <> "") And (DOJ.Text <> "") And (BASIC.Text <> "") And (DA.Text <> "") And (HRA.Text <> "") And (CCA.Text <> "") And (PF.Text <> "") And (TAX.Text <> "") And (GROSS.Text <> "") And (NET.Text <> "")) Then
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "insert into payroll values('" + EMPNO.Text + "','" + ENAME.Text + "','" + DESIG.Text + "','" + DOJ.Text + "','" + BASIC.Text + "','" + DA.Text + "','" + HRA.Text + "','" + CCA.Text + "','" + PF.Text + "','" + TAX.Text + "','" + GROSS.Text + "','" + NET.Text(+"')")
                cmd.ExecuteNonQuery()
                EMPNO.Text = ""
                ENAME.Text = ""
                DESIG.Text = ""
                DOJ.Text = " "
                BASIC.Text = " "
                DA.Text = ""
                HRA.Text = ""
                CCA.Text = ""
                PF.Text = ""
                TAX.Text = " "
                GROSS.Text = ""
                NET.Text = ""
                MessageBox.Show("updated successfully")
            Else
                MsgBox("Enter Employee Details")
            End If
        Catch ex As Exception
            MsgBox("Enter Employee Number")
        End Try
        disp_data()
    End Sub

    Private Sub UPDATE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UPDATE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to update this record?", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "update payroll set name =' " + ENAME.Text + "',DESIG='" + DESIG.Text + "',DOJ='" + DOJ.Text + "',BASIC='" + BASIC.Text + "',DA='" + DA.Text + "',HRA='" + HRA.Text + "',CCA='" + CCA.Text + "',PF='" + PF.Text + "',GROSS='" + GROSS.Text(+"',NET='" + NET.Text + "' where EMPNO = '" + EMPNO.Text + "'")
            cmd.ExecuteNonQuery()
        End If
        disp_data()
    End Sub

    Private Sub DELETE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DELETE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to Delete this record??", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "delete from payroll where EMPNO = '" + EMPNO.Text + "'"
            cmd.ExecuteNonQuery()
        End If
        disp_data()
    End Sub

    Private Sub CLEAR1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CLEAR1.Click
        EMPNO.Text = ""
        ENAME.Text = ""
        DESIG.Text = ""
        DOJ.Text = " "
        BASIC.Text = " "
        DA.Text = ""
        HRA.Text = ""
        CCA.Text = ""
        PF.Text = ""
        TAX.Text = " "
        GROSS.Text = ""
        NET.Text = ""
    End Sub

    Private Sub EXIT1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXIT1.Click
        End
    End Sub

    Private Sub BASIC_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles BASIC.LostFocus
        DA.Text = Val(BASIC.Text) * 25 / 100
        HRA.Text = Val(BASIC.Text) * 30 / 100
        CCA.Text = Val(BASIC.Text) * 15 / 100
        PF.Text = Val(BASIC.Text) * 12.5 / 100
        TAX.Text = Val(BASIC.Text) * 10 / 100
        GROSS.Text = Val(DA.Text) + Val(HRA.Text) + Val(CCA.Text)
        NET.Text = Val(GROSS.Text) - Val(PF.Text) - Val(TAX.Text)
    End Sub
End Class
