﻿Imports System.Data.OracleClient
Public Class Form1
    Dim con As OracleConnection
    Dim cmd As OracleCommand
    Dim obreader As OracleDataReader
    Dim id As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)Handles MyBase.Load
        con = New OracleConnection("Data source= ashok;user id = scott;password = tiger")
        con.Open()
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        disp_data()
    End Sub

    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from purchase order by pord"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New OracleDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub


    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick, DataGridView1.CellClick
        id = DataGridView1.SelectedCells.Item(0).Value.ToString()
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            pord.Text = row.Cells(0).Value.ToString
            vname.Text = row.Cells(1).Value.ToString
            odate.Text = row.Cells(2).Value.ToString
            pname.Text = row.Cells(3).Value.ToString
            Rate.Text = row.Cells(4).Value.ToString
            qty.Text = row.Cells(5).Value.ToString
            amt.Text = row.Cells(6).Value.ToString
        End If
    End Sub

    Private Sub ADD1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADD1.Click
        pord.Text = ""
        vname.Text = ""
        odate.Text = ""
        pname.Text = " "
        Rate.Text = ""
        qty.Text = " "
        amt.Text = ""
        pord.Focus()
    End Sub


    Private Sub SAVE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SAVE1.Click
        Try
            If ((pord.Text <> "") And (vname.Text <> "") And (odate.Text <> "") And (pname.Text <> "") And (Rate.Text <> "") And (qty.Text <> "") And (amt.Text <> "")) Then
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "insert into purchase values('" + pord.Text + "','" + vname.Text + "','" + odate.Text + "','" + pname.Text + "','" + Rate.Text + "','" + qty.Text + "','" + amt.Text + "')"
                cmd.ExecuteNonQuery()
                pord.Text = ""
                vname.Text = ""
                odate.Text = ""
                pname.Text = " "
                Rate.Text = ""
                qty.Text = " "
                amt.Text = ""
                disp_data()
                MessageBox.Show("updated successfully")
            Else
                MsgBox("ADD Purchse order INf")
            End If
        Catch ex As Exception
            MsgBox("ADD Purchase order Details")
        End Try
    End Sub


    Private Sub CLEAR1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CLEAR1.Click
        pord.Text = ""
        vname.Text = ""
        odate.Text = ""
        pname.Text = " "
        Rate.Text = ""
        qty.Text = " "
        amt.Text = ""
    End Sub


    Private Sub UPDATE1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles UPDATE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to update this record?", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "update purchase set name ='" + vname.Text + "' where pord = '" + pord.Text + "'"
            cmd.ExecuteNonQuery()
        End If
        disp_data()
    End Sub


    Private Sub DELETE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DELETE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to Delete this record??", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "delete from purchase where pord = '" + pord.Text + "'"
            cmd.ExecuteNonQuery()
        End If
    End Sub

    Private Sub odate_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles odate.GotFocus
        odate.Text = Date.Today
    End Sub

    Private Sub qty_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles qty.LostFocus
        amt.Text = Val(Rate.Text) * Val(qty.Text)
    End Sub

    Private Sub EXIT1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXIT1.Click
        End
    End Sub
End Class
