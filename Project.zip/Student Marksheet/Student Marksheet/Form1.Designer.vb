﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.ADD1 = New System.Windows.Forms.Button
        Me.SAVE1 = New System.Windows.Forms.Button
        Me.UPDATE1 = New System.Windows.Forms.Button
        Me.DELETE1 = New System.Windows.Forms.Button
        Me.CLEAR1 = New System.Windows.Forms.Button
        Me.EXIT1 = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.cplab = New System.Windows.Forms.TextBox
        Me.Class1 = New System.Windows.Forms.TextBox
        Me.Res = New System.Windows.Forms.TextBox
        Me.Avg = New System.Windows.Forms.TextBox
        Me.Tot = New System.Windows.Forms.TextBox
        Me.dbmslab = New System.Windows.Forms.TextBox
        Me.mname = New System.Windows.Forms.TextBox
        Me.dob = New System.Windows.Forms.TextBox
        Me.dcpp = New System.Windows.Forms.TextBox
        Me.dcf = New System.Windows.Forms.TextBox
        Me.dbms = New System.Windows.Forms.TextBox
        Me.rno = New System.Windows.Forms.TextBox
        Me.afm = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(265, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(217, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Student Mark sheet"
        '
        'ADD1
        '
        Me.ADD1.Location = New System.Drawing.Point(74, 348)
        Me.ADD1.Name = "ADD1"
        Me.ADD1.Size = New System.Drawing.Size(75, 36)
        Me.ADD1.TabIndex = 1
        Me.ADD1.Text = "ADD"
        Me.ADD1.UseVisualStyleBackColor = True
        '
        'SAVE1
        '
        Me.SAVE1.Location = New System.Drawing.Point(156, 348)
        Me.SAVE1.Name = "SAVE1"
        Me.SAVE1.Size = New System.Drawing.Size(75, 36)
        Me.SAVE1.TabIndex = 2
        Me.SAVE1.Text = "SAVE"
        Me.SAVE1.UseVisualStyleBackColor = True
        '
        'UPDATE1
        '
        Me.UPDATE1.Location = New System.Drawing.Point(239, 348)
        Me.UPDATE1.Name = "UPDATE1"
        Me.UPDATE1.Size = New System.Drawing.Size(75, 36)
        Me.UPDATE1.TabIndex = 3
        Me.UPDATE1.Text = "UPDATE"
        Me.UPDATE1.UseVisualStyleBackColor = True
        '
        'DELETE1
        '
        Me.DELETE1.Location = New System.Drawing.Point(320, 348)
        Me.DELETE1.Name = "DELETE1"
        Me.DELETE1.Size = New System.Drawing.Size(75, 36)
        Me.DELETE1.TabIndex = 4
        Me.DELETE1.Text = "DELETE"
        Me.DELETE1.UseVisualStyleBackColor = True
        '
        'CLEAR1
        '
        Me.CLEAR1.Location = New System.Drawing.Point(402, 347)
        Me.CLEAR1.Name = "CLEAR1"
        Me.CLEAR1.Size = New System.Drawing.Size(75, 36)
        Me.CLEAR1.TabIndex = 5
        Me.CLEAR1.Text = "CLEAR"
        Me.CLEAR1.UseVisualStyleBackColor = True
        '
        'EXIT1
        '
        Me.EXIT1.Location = New System.Drawing.Point(484, 347)
        Me.EXIT1.Name = "EXIT1"
        Me.EXIT1.Size = New System.Drawing.Size(75, 36)
        Me.EXIT1.TabIndex = 6
        Me.EXIT1.Text = "EXIT"
        Me.EXIT1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(498, 106)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(249, 150)
        Me.DataGridView1.TabIndex = 7
        '
        'cplab
        '
        Me.cplab.Location = New System.Drawing.Point(340, 103)
        Me.cplab.Name = "cplab"
        Me.cplab.Size = New System.Drawing.Size(100, 20)
        Me.cplab.TabIndex = 8
        '
        'Class1
        '
        Me.Class1.Location = New System.Drawing.Point(340, 237)
        Me.Class1.Name = "Class1"
        Me.Class1.Size = New System.Drawing.Size(100, 20)
        Me.Class1.TabIndex = 10
        '
        'Res
        '
        Me.Res.Location = New System.Drawing.Point(340, 211)
        Me.Res.Name = "Res"
        Me.Res.Size = New System.Drawing.Size(100, 20)
        Me.Res.TabIndex = 11
        '
        'Avg
        '
        Me.Avg.Location = New System.Drawing.Point(340, 181)
        Me.Avg.Name = "Avg"
        Me.Avg.Size = New System.Drawing.Size(100, 20)
        Me.Avg.TabIndex = 12
        '
        'Tot
        '
        Me.Tot.Location = New System.Drawing.Point(340, 155)
        Me.Tot.Name = "Tot"
        Me.Tot.Size = New System.Drawing.Size(100, 20)
        Me.Tot.TabIndex = 13
        '
        'dbmslab
        '
        Me.dbmslab.Location = New System.Drawing.Point(340, 129)
        Me.dbmslab.Name = "dbmslab"
        Me.dbmslab.Size = New System.Drawing.Size(100, 20)
        Me.dbmslab.TabIndex = 14
        '
        'mname
        '
        Me.mname.Location = New System.Drawing.Point(131, 129)
        Me.mname.Name = "mname"
        Me.mname.Size = New System.Drawing.Size(100, 20)
        Me.mname.TabIndex = 20
        '
        'dob
        '
        Me.dob.Location = New System.Drawing.Point(131, 155)
        Me.dob.Name = "dob"
        Me.dob.Size = New System.Drawing.Size(100, 20)
        Me.dob.TabIndex = 19
        '
        'dcpp
        '
        Me.dcpp.Location = New System.Drawing.Point(131, 181)
        Me.dcpp.Name = "dcpp"
        Me.dcpp.Size = New System.Drawing.Size(100, 20)
        Me.dcpp.TabIndex = 18
        '
        'dcf
        '
        Me.dcf.Location = New System.Drawing.Point(131, 211)
        Me.dcf.Name = "dcf"
        Me.dcf.Size = New System.Drawing.Size(100, 20)
        Me.dcf.TabIndex = 17
        '
        'dbms
        '
        Me.dbms.Location = New System.Drawing.Point(131, 237)
        Me.dbms.Name = "dbms"
        Me.dbms.Size = New System.Drawing.Size(100, 20)
        Me.dbms.TabIndex = 16
        '
        'rno
        '
        Me.rno.Location = New System.Drawing.Point(131, 103)
        Me.rno.Name = "rno"
        Me.rno.Size = New System.Drawing.Size(100, 20)
        Me.rno.TabIndex = 15
        '
        'afm
        '
        Me.afm.Location = New System.Drawing.Point(131, 263)
        Me.afm.Name = "afm"
        Me.afm.Size = New System.Drawing.Size(100, 20)
        Me.afm.TabIndex = 21
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(65, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Regno"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(65, 136)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(65, 162)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "date of birth"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(65, 188)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "c++ using ds"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(65, 270)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(29, 13)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "AFM"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(65, 244)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 13)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "dbms"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(65, 217)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(22, 13)
        Me.Label9.TabIndex = 26
        Me.Label9.Text = "dcf"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(269, 242)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 13)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Class"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(269, 214)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 13)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Result"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(269, 185)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(47, 13)
        Me.Label11.TabIndex = 32
        Me.Label11.Text = "Average"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(269, 159)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 13)
        Me.Label12.TabIndex = 31
        Me.Label12.Text = "TOTAL"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(269, 133)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(61, 13)
        Me.Label13.TabIndex = 30
        Me.Label13.Text = "DBMS LAB"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(269, 106)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(51, 13)
        Me.Label14.TabIndex = 29
        Me.Label14.Text = "CPP LAB"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(819, 447)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.afm)
        Me.Controls.Add(Me.mname)
        Me.Controls.Add(Me.dob)
        Me.Controls.Add(Me.dcpp)
        Me.Controls.Add(Me.dcf)
        Me.Controls.Add(Me.dbms)
        Me.Controls.Add(Me.rno)
        Me.Controls.Add(Me.dbmslab)
        Me.Controls.Add(Me.Tot)
        Me.Controls.Add(Me.Avg)
        Me.Controls.Add(Me.Res)
        Me.Controls.Add(Me.Class1)
        Me.Controls.Add(Me.cplab)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.EXIT1)
        Me.Controls.Add(Me.CLEAR1)
        Me.Controls.Add(Me.DELETE1)
        Me.Controls.Add(Me.UPDATE1)
        Me.Controls.Add(Me.SAVE1)
        Me.Controls.Add(Me.ADD1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ADD1 As System.Windows.Forms.Button
    Friend WithEvents SAVE1 As System.Windows.Forms.Button
    Friend WithEvents UPDATE1 As System.Windows.Forms.Button
    Friend WithEvents DELETE1 As System.Windows.Forms.Button
    Friend WithEvents CLEAR1 As System.Windows.Forms.Button
    Friend WithEvents EXIT1 As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents cplab As System.Windows.Forms.TextBox
    Friend WithEvents Class1 As System.Windows.Forms.TextBox
    Friend WithEvents Res As System.Windows.Forms.TextBox
    Friend WithEvents Avg As System.Windows.Forms.TextBox
    Friend WithEvents Tot As System.Windows.Forms.TextBox
    Friend WithEvents dbmslab As System.Windows.Forms.TextBox
    Friend WithEvents mname As System.Windows.Forms.TextBox
    Friend WithEvents dob As System.Windows.Forms.TextBox
    Friend WithEvents dcpp As System.Windows.Forms.TextBox
    Friend WithEvents dcf As System.Windows.Forms.TextBox
    Friend WithEvents dbms As System.Windows.Forms.TextBox
    Friend WithEvents rno As System.Windows.Forms.TextBox
    Friend WithEvents afm As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label

End Class
