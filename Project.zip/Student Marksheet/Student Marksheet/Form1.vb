﻿Imports System.Data.OracleClient
Public Class Form1
    Dim con As OracleConnection
    Dim cmd As OracleCommand
    Dim obreader As OracleDataReader
    Dim id As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New OracleConnection("Data source= rdbms;user id = stud;password = stud")
        con.Open()
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        disp_data()
    End Sub

    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from stumarks order by regno"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New OracleDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub rno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rno.TextChanged

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick, DataGridView1.CellClick
        id = DataGridView1.SelectedCells.Item(0).Value.ToString()
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            rno.Text = row.Cells(0).Value.ToString
            mname.Text = row.Cells(1).Value.ToString
            dob.Text = row.Cells(2).Value.ToString
            dcpp.Text = row.Cells(3).Value.ToString
            dcf.Text = row.Cells(4).Value.ToString
            dbms.Text = row.Cells(5).Value.ToString
            afm.Text = row.Cells(6).Value.ToString
            cplab.Text = row.Cells(7).Value.ToString
            dbmslab.Text = row.Cells(8).Value.ToString
            Tot.Text = row.Cells(9).Value.ToString
            Avg.Text = row.Cells(10).Value.ToString
            Res.Text = row.Cells(11).Value.ToString
            Class1.Text = row.Cells(12).Value.ToString
        End If
    End Sub

    Private Sub ADD1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADD1.Click
        rno.Text = ""
        mname.Text = ""
        dob.Text = ""
        dcpp.Text = " "
        dcf.Text = " "
        dbms.Text = ""
        afm.Text = ""
        cplab.Text = ""
        dbmslab.Text = ""
        Tot.Text = " "
        Avg.Text = ""
        Res.Text = ""
        Class1.Text = ""
        mname.Focus()
    End Sub

    Private Sub SAVE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SAVE1.Click
        Try
            If ((rno.Text <> "") And (mname.Text <> "") And (dob.Text <> "") And (dcpp.Text <> "") And (dcf.Text <> "") And (dbms.Text <> "") And (afm.Text <> "") And (cplab.Text <> "") And (dbmslab.Text <> "") And (Tot.Text <> "") And (Avg.Text <> "") And (Res.Text <> "") And (Class1.Text <> "")) Then
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "insert into stumarks values('" + rno.Text + "','" + mname.Text + "','" + dob.Text + "','" + dcpp.Text + "','" + dcf.Text + "','" + dbms.Text + "','" + afm.Text + "','" + cplab.Text + "','" + dbmslab.Text + "','" + Tot.Text + "','" + Avg.Text + "','" + Res.Text + "','" + Class1.Text(+"')")
                cmd.ExecuteNonQuery()
                rno.Text = ""
                mname.Text = ""
                dob.Text = ""
                dcpp.Text = " "
                dcf.Text = " "
                dbms.Text = ""
                afm.Text = ""
                cplab.Text = ""
                dbmslab.Text = ""
                Tot.Text = " "
                Avg.Text = ""
                Res.Text = ""
                Class1.Text = ""
                MessageBox.Show("updated successfully")
            Else
                MsgBox("Enter stud marks Details")
            End If
        Catch ex As Exception
            MsgBox("Enter Registration Number")
        End Try
        disp_data()
    End Sub


    Private Sub UPDATE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UPDATE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to update this record?", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "update stumarks set name ='" + mname.Text + "',dob ='" + dob.Text + "',dsc='" + dcpp.Text + "',dcf='" + dcf.Text + "',dbms='" + dbms.Text + "',af='" + afm.Text + "',clab='" + cplab.Text + "',rdbmslab='" + dbmslab.Text + "' where regno = '" + rno.Text(+"'")
            cmd.ExecuteNonQuery()
        End If
        disp_data()
    End Sub


    Private Sub DELETE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DELETE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to Delete this record??", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "delete from stumarks where regno = '" + rno.Text + "'"
            cmd.ExecuteNonQuery()
        End If
        disp_data()
    End Sub

    Private Sub CLEAR1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CLEAR1.Click
        rno.Text = ""
        mname.Text = ""
        dob.Text = ""
        dcpp.Text = " "
        dcf.Text = " "
        dbms.Text = ""
        afm.Text = ""
        cplab.Text = ""
        dbmslab.Text = ""
        Tot.Text = " "
        Avg.Text = ""
        Res.Text = ""
        Class1.Text = ""
    End Sub

    Private Sub dbmslab_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles dbmslab.LostFocus
        Tot.Text = Val(dcpp.Text) + Val(dcf.Text) + Val(dbms.Text) + Val(afm.Text) + Val(cplab.Text) + Val(dbmslab.Text)
        Avg.Text = Val(Tot.Text) / 6
        If (Val(dcpp.Text) >= 40) And (Val(dcf.Text) >= 40) And (Val(dbms.Text) >= 40) And (Val(afm.Text) >= 40) And (Val(cplab.Text) >= 40) And (Val(dbmslab.Text) >= 40) Then
            Res.Text = "pass"
            If Val(Avg.Text) >= 90 Then
                Class1.Text = "Distinction"
            ElseIf Val(Avg.Text) >= 60 And Val(Avg.Text) < 80 Then
                Class1.Text = "first"
            Else
                Class1.Text = "second"
            End If
        Else
            Res.Text = "fail"
            Class1.Text = "NIL"
        End If
    End Sub

    Private Sub EXIT1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXIT1.Click
        End
    End Sub
End Class
