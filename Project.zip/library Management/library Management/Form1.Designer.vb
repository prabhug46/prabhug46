﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ADD = New System.Windows.Forms.Button
        Me.SAVE = New System.Windows.Forms.Button
        Me.DELETE1 = New System.Windows.Forms.Button
        Me.CLEAR = New System.Windows.Forms.Button
        Me.EXIT1 = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Isid = New System.Windows.Forms.TextBox
        Me.bname = New System.Windows.Forms.TextBox
        Me.memid = New System.Windows.Forms.TextBox
        Me.isdate = New System.Windows.Forms.TextBox
        Me.rdate = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ADD
        '
        Me.ADD.Location = New System.Drawing.Point(88, 308)
        Me.ADD.Name = "ADD"
        Me.ADD.Size = New System.Drawing.Size(75, 23)
        Me.ADD.TabIndex = 0
        Me.ADD.Text = "ADD"
        Me.ADD.UseVisualStyleBackColor = True
        '
        'SAVE
        '
        Me.SAVE.Location = New System.Drawing.Point(175, 308)
        Me.SAVE.Name = "SAVE"
        Me.SAVE.Size = New System.Drawing.Size(75, 23)
        Me.SAVE.TabIndex = 1
        Me.SAVE.Text = "SAVE"
        Me.SAVE.UseVisualStyleBackColor = True
        '
        'DELETE1
        '
        Me.DELETE1.Location = New System.Drawing.Point(262, 308)
        Me.DELETE1.Name = "DELETE1"
        Me.DELETE1.Size = New System.Drawing.Size(75, 23)
        Me.DELETE1.TabIndex = 2
        Me.DELETE1.Text = "DELETE"
        Me.DELETE1.UseVisualStyleBackColor = True
        '
        'CLEAR
        '
        Me.CLEAR.Location = New System.Drawing.Point(356, 308)
        Me.CLEAR.Name = "CLEAR"
        Me.CLEAR.Size = New System.Drawing.Size(75, 23)
        Me.CLEAR.TabIndex = 3
        Me.CLEAR.Text = "CLEAR"
        Me.CLEAR.UseVisualStyleBackColor = True
        '
        'EXIT1
        '
        Me.EXIT1.Location = New System.Drawing.Point(455, 308)
        Me.EXIT1.Name = "EXIT1"
        Me.EXIT1.Size = New System.Drawing.Size(75, 23)
        Me.EXIT1.TabIndex = 4
        Me.EXIT1.Text = "EXIT"
        Me.EXIT1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(419, 82)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(240, 150)
        Me.DataGridView1.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "ISSUE ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(60, 106)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "BOOK NAME"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(60, 139)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "MEMBER ID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(60, 177)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "ISSUE DATE"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(60, 219)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "RETURN DATE"
        '
        'Isid
        '
        Me.Isid.Location = New System.Drawing.Point(150, 75)
        Me.Isid.Name = "Isid"
        Me.Isid.Size = New System.Drawing.Size(100, 20)
        Me.Isid.TabIndex = 11
        '
        'bname
        '
        Me.bname.Location = New System.Drawing.Point(150, 106)
        Me.bname.Name = "bname"
        Me.bname.Size = New System.Drawing.Size(100, 20)
        Me.bname.TabIndex = 12
        '
        'memid
        '
        Me.memid.Location = New System.Drawing.Point(150, 139)
        Me.memid.Name = "memid"
        Me.memid.Size = New System.Drawing.Size(100, 20)
        Me.memid.TabIndex = 13
        '
        'isdate
        '
        Me.isdate.Location = New System.Drawing.Point(150, 170)
        Me.isdate.Name = "isdate"
        Me.isdate.Size = New System.Drawing.Size(100, 20)
        Me.isdate.TabIndex = 14
        '
        'rdate
        '
        Me.rdate.Location = New System.Drawing.Point(150, 212)
        Me.rdate.Name = "rdate"
        Me.rdate.Size = New System.Drawing.Size(100, 20)
        Me.rdate.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(169, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(350, 31)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "LIBRARY MANAGEMENT"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(729, 404)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.rdate)
        Me.Controls.Add(Me.isdate)
        Me.Controls.Add(Me.memid)
        Me.Controls.Add(Me.bname)
        Me.Controls.Add(Me.Isid)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.EXIT1)
        Me.Controls.Add(Me.CLEAR)
        Me.Controls.Add(Me.DELETE1)
        Me.Controls.Add(Me.SAVE)
        Me.Controls.Add(Me.ADD)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ADD As System.Windows.Forms.Button
    Friend WithEvents SAVE As System.Windows.Forms.Button
    Friend WithEvents DELETE1 As System.Windows.Forms.Button
    Friend WithEvents CLEAR As System.Windows.Forms.Button
    Friend WithEvents EXIT1 As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Isid As System.Windows.Forms.TextBox
    Friend WithEvents bname As System.Windows.Forms.TextBox
    Friend WithEvents memid As System.Windows.Forms.TextBox
    Friend WithEvents isdate As System.Windows.Forms.TextBox
    Friend WithEvents rdate As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label

End Class
