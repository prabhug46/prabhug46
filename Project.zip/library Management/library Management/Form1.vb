﻿Imports System.Data.OracleClient
Public Class Form1
    Dim con As OracleConnection
    Dim cmd As OracleCommand
    Dim obreader As OracleDataReader
    Dim id As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New OracleConnection("Data source= ashok;user id = scott;password = tiger")
        con.Open()
        disp_data()
    End Sub

    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from issue"
        cmd.ExecuteNonQuery()
        Dim da As New OracleDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick, DataGridView1.CellClick
        id = DataGridView1.SelectedCells.Item(0).Value.ToString()
        If (e.RowIndex) >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            Isid.Text = row.Cells(0).Value.ToString
            bname.Text = row.Cells(1).Value.ToString
            memid.Text = row.Cells(2).Value.ToString
            IsDate.Text = row.Cells(3).Value.ToString
            rdate.Text = row.Cells(4).Value.ToString
        End If
    End Sub


    Private Sub Isid_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Isid.GotFocus
        isdate.Text = Date.Today
        rdate.Text = Date.Today.AddDays(15)
    End Sub

    Private Sub CLEAR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CLEAR.Click
        Isid.Text = ""
        bname.Text = ""
        memid.Text = ""
        isdate.Text = ""
        rdate.Text = ""
    End Sub

    Private Sub ADD_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ADD.Click
        Isid.Text = ""
        bname.Text = ""
        memid.Text = ""
        isdate.Text = ""
        rdate.Text = ""
        Isid.Focus()
    End Sub

    Private Sub SAVE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SAVE.Click
        Try
            If ((Isid.Text <> "") And (bname.Text <> "") And (memid.Text <> "") And (isdate.Text <> "") And (rdate.Text <> "")) Then
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "insert into issue values('" + Isid.Text + "','" + bname.Text + "','" + memid.Text + "','" + isdate.Text + "','" + rdate.Text + "')"
                cmd.ExecuteNonQuery()
                Isid.Text = ""
                bname.Text = ""
                memid.Text = ""
                isdate.Text = " "
                rdate.Text = " "
                MessageBox.Show("saved successfully")
            Else
                MsgBox("Enter book Details")
            End If
        Catch ex As Exception
            MsgBox("Enter details")
        End Try
        disp_data()
    End Sub

    Private Sub DELETE1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DELETE1.Click
        Dim opt As Integer
        opt = MsgBox("Do you want to Delete this record??", vbYesNo)
        If (opt = vbYes) Then
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "delete from issue where issueid = '" + Isid.Text + "'"
            cmd.ExecuteNonQuery()
        End If
        disp_data()
    End Sub

    Private Sub EXIT1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles EXIT1.Click
        End
    End Sub
End Class
