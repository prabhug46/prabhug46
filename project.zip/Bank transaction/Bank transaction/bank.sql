CREATE TABLE bank (
    accno   VARCHAR2(10)  NOT NULL PRIMARY KEY,
    acid    VARCHAR2(20),
    cname   VARCHAR2(20),
    pbal    VARCHAR2(20),
    acctype VARCHAR2(10),
    amt     NUMBER(10,2),
    dat     VARCHAR2(15),
    curbal  NUMBER(12,2)
);
