CREATE TABLE stumarks (
    regno      VARCHAR2(10) PRIMARY KEY,
    name       VARCHAR2(15),
    dob        VARCHAR2(15),
    dsc        NUMBER(3),
    dcf        NUMBER(3),
    dbms       NUMBER(3),
    af         NUMBER(3),
    clab       NUMBER(3),
    rdbmslab   NUMBER(3),
    total      NUMBER(5),
    avg        NUMBER(5,2),
    result     VARCHAR2(5),
    class      VARCHAR2(15)
);
